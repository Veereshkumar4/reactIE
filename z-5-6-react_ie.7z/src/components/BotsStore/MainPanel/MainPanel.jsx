import "./MainPanel.css";
import React from "react";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import BotCard from '../BotCard'

function template() {
  return (
 <div/>
  );
};

export default template;
