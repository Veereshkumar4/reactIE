import React    from "react";
import template from "./BotsStore.jsx";

class BotsStore extends React.Component {
  render() {
    return template.call(this);
  }
}

export default BotsStore;
