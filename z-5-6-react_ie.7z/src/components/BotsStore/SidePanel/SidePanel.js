import React    from "react";
import template from "./SidePanel.jsx";

class SidePanel extends React.Component {
  render() {
    return template.call(this);
  }
}

export default SidePanel;
