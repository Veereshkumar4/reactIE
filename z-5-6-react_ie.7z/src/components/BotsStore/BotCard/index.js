import BotCard from "./BotCard";
export default BotCard;
