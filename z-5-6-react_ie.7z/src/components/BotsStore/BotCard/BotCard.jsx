import "./BotCard.css";
import React from "react";
import StarRatingComponent from 'react-star-rating-component';
import {withRouter} from "react-router-dom";

function template() {
 
};

export default withRouter(template);
