import BotsStore from "./BotsStore";
export default BotsStore;
