import BotsInfo from "./BotsInfo";
export default BotsInfo;
