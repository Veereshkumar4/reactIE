import "./Tabs.css";
import React from "react";

function template() {
  return (
    <div className="tabs">
      <h1>Tabs</h1>
    </div>
  );
};

export default template;
