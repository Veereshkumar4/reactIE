import React    from "react";
import template from "./Tabs.jsx";

class Tabs extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Tabs;
